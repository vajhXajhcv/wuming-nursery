"""
Format existing docx files according to a template preset.

Applies:
- Page setup (size, margins)
- Heading detection and re-styling
- Body paragraph normalization (font, size, line spacing, indent)
- Table three-line styling
- Image center alignment
- Header/footer (page number)
- Optional: regenerate TOC
"""

import re
from docx import Document
from docx.shared import Pt, Mm, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from .config import TemplateConfig
from .converter.docx_builder import _setup_page, _setup_styles, _setup_header_footer, _align_wd
from .converter.toc import insert_toc


def format_existing_docx(input_path: str, output_path: str, config: TemplateConfig,
                         add_toc: bool = False):
    """Load an existing docx and apply template formatting."""
    doc = Document(input_path)

    # 1. Page setup
    _setup_page(doc, config)

    # 2. Styles (define styles in document)
    _setup_styles(doc, config)

    # 3. Header / footer
    _setup_header_footer(doc, config)

    # 4. Detect and normalize all paragraphs
    for para in doc.paragraphs:
        _classify_and_normalize_para(para, config)

    # 5. Format tables
    for table in doc.tables:
        _format_table(table, config)

    # 6. Center images
    for para in doc.paragraphs:
        _center_images(para)

    # 7. Optionally insert TOC at beginning
    if add_toc and doc.paragraphs:
        _insert_toc_at_top(doc, config)

    doc.save(output_path)


def _classify_and_normalize_para(para, config: TemplateConfig):
    """Detect paragraph type and apply appropriate formatting."""
    text = para.text.strip()
    if not text:
        return

    # Get original formatting hints
    first_run = para.runs[0] if para.runs else None
    orig_size = _get_run_size_pt(first_run) if first_run else None
    orig_bold = first_run.bold if first_run else False
    style_name = para.style.name if para.style else "Normal"

    # Detect heading level
    level = _detect_heading_level(text, style_name, orig_size, orig_bold)

    if level:
        _apply_heading_style(para, level, config)
    elif _is_reference_line(text):
        _apply_reference_style(para, config)
    elif _is_toc_line(text):
        _apply_toc_style(para, config)
    else:
        _apply_body_style(para, config)


def _detect_heading_level(text: str, style_name: str, orig_size, orig_bold) -> int:
    """Detect heading level from various signals."""
    # Style-based detection
    if "Heading 1" in style_name:
        return 1
    if "Heading 2" in style_name:
        return 2
    if "Heading 3" in style_name:
        return 3
    if "Heading 4" in style_name or "Heading 5" in style_name or "Heading 6" in style_name:
        return 4

    # Text pattern detection
    # Chapter titles: "第一章", "第1章", "1 绪论", "一、"
    if re.match(r'^(第[一二三四五六七八九十百千]+章|第\d+章)\s*', text):
        return 1
    # Section titles: "1.1", "1.1.1", "（一）", "(1)"
    if re.match(r'^\d+\.\d+\s+', text):
        # Distinguish h2 vs h3 by depth
        parts = text.split()[0].split('.')
        if len(parts) == 2:
            return 2
        if len(parts) >= 3:
            return 3
    if re.match(r'^（[一二三四五六七八九十]+）\s*', text):
        return 2
    if re.match(r'^\([\d一二三四五六七八九十]+\)\s*', text):
        return 3

    # Size-based detection (as fallback)
    if orig_size and orig_bold:
        if orig_size >= 18:
            return 1
        if orig_size >= 16:
            return 2
        if orig_size >= 14:
            return 3
        if orig_size >= 12:
            return 4

    # Special keywords
    if text in ("摘要", "ABSTRACT", "目录", "致谢", "参考文献", "结论", "附录"):
        return 1

    return 0


def _apply_heading_style(para, level: int, config: TemplateConfig):
    """Apply heading formatting to a paragraph."""
    sizes = [0, config.heading.h1_size_pt, config.heading.h2_size_pt,
             config.heading.h3_size_pt, config.heading.h4_size_pt]
    size_pt = sizes[level]

    # Apply style name if available
    try:
        para.style = para.part.document.styles[f"Heading {level}"]
    except (KeyError, AttributeError):
        pass

    # Direct formatting fallback
    pf = para.paragraph_format
    pf.alignment = _align_wd(config.heading.alignment)
    pf.first_line_indent = Cm(0)
    pf.space_before = Pt(12)
    pf.space_after = Pt(6)
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = config.body.line_spacing

    for run in para.runs:
        run.font.name = config.font.heading_english
        run.font.size = Pt(size_pt)
        run.font.bold = config.heading.bold
        _set_east_asia(run, config.font.heading_chinese)


def _apply_body_style(para, config: TemplateConfig):
    """Apply body text formatting."""
    pf = para.paragraph_format
    pf.alignment = _align_wd(config.body.alignment)
    pf.first_line_indent = Cm(config.body.first_line_indent_chars * 0.35)
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = config.body.line_spacing
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)

    for run in para.runs:
        run.font.name = config.font.english
        run.font.size = Pt(config.body.size_pt)
        run.font.bold = False
        _set_east_asia(run, config.font.chinese)


def _apply_reference_style(para, config: TemplateConfig):
    """Apply reference list formatting."""
    pf = para.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
    pf.first_line_indent = Cm(0)
    pf.left_indent = Cm(0.74)  # [n] 宽度
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = config.body.line_spacing

    for run in para.runs:
        run.font.name = config.font.english
        run.font.size = Pt(config.reference.font_size_pt)
        _set_east_asia(run, config.font.chinese)


def _apply_toc_style(para, config: TemplateConfig):
    """Apply TOC paragraph formatting."""
    pf = para.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
    pf.first_line_indent = Cm(0)
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = config.body.line_spacing

    for run in para.runs:
        run.font.name = config.font.english
        run.font.size = Pt(config.body.size_pt)
        _set_east_asia(run, config.font.chinese)


def _is_reference_line(text: str) -> bool:
    """Detect reference lines like [1], [2] etc."""
    return bool(re.match(r'^\[\d+\]', text.strip()))


def _is_toc_line(text: str) -> bool:
    """Detect TOC lines with dots and page numbers."""
    return bool(re.search(r'\.\s*\.{3,}\s*\d+$', text))


def _get_run_size_pt(run) -> float:
    """Extract font size in points from a run."""
    if run is None:
        return 0
    if run.font.size:
        return run.font.size.pt
    # Try XML fallback
    rpr = run._element.find(qn("w:rPr"))
    if rpr is not None:
        sz = rpr.find(qn("w:sz"))
        if sz is not None:
            val = sz.get(qn("w:val"))
            if val:
                return int(val) / 2
    return 0


def _format_table(table, config: TemplateConfig):
    """Apply three-line table style with short-cell nowrap and page keep."""
    if not table.rows:
        return

    # Set table font, nowrap for short cells, keep row on same page
    for row in table.rows:
        # Keep row from splitting across pages
        tr = row._tr
        trPr = tr.get_or_add_trPr()
        cantSplit = OxmlElement("w:cantSplit")
        trPr.append(cantSplit)

        for cell in row.cells:
            cell_text = cell.text.strip().replace(" ", "").replace("\n", "")
            tc = cell._tc
            tcPr = tc.get_or_add_tcPr()

            # Short cells: no wrap
            if len(cell_text) <= 5:
                noWrap = OxmlElement("w:noWrap")
                tcPr.append(noWrap)

            for para in cell.paragraphs:
                para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in para.runs:
                    run.font.size = Pt(config.table.font_size_pt)
                    run.font.name = config.font.english
                    _set_east_asia(run, config.font.chinese)

    # Apply borders
    tbl = table._tbl
    tblPr = tbl.tblPr if tbl.tblPr is not None else OxmlElement("w:tblPr")

    # Remove all existing borders
    borders = tblPr.find(qn("w:tblBorders"))
    if borders is not None:
        tblPr.remove(borders)

    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        edge_el = OxmlElement(f"w:{edge}")
        edge_el.set(qn("w:val"), "none")
        edge_el.set(qn("w:sz"), "0")
        edge_el.set(qn("w:space"), "0")
        edge_el.set(qn("w:color"), "auto")
        borders.append(edge_el)
    tblPr.append(borders)

    # Top border of header row
    if table.rows:
        _set_row_border(table.rows[0], "top", config.table.header_border_width_pt)
        _set_row_border(table.rows[0], "bottom", config.table.header_border_width_pt)

    # Bottom border of last row
    if table.rows:
        _set_row_border(table.rows[-1], "bottom", config.table.bottom_border_width_pt)

    # Center table
    table.alignment = WD_TABLE_ALIGNMENT.CENTER


def _set_row_border(row, edge: str, width_pt: float):
    """Set border for all cells in a row."""
    for cell in row.cells:
        tc = cell._tc
        tcPr = tc.get_or_add_tcPr()
        tcBorders = tcPr.find(qn("w:tcBorders"))
        if tcBorders is None:
            tcBorders = OxmlElement("w:tcBorders")
            tcPr.append(tcBorders)
        edge_el = OxmlElement(f"w:{edge}")
        edge_el.set(qn("w:val"), "single")
        edge_el.set(qn("w:sz"), str(int(width_pt * 4)))  # eighths of a point
        edge_el.set(qn("w:space"), "0")
        edge_el.set(qn("w:color"), "000000")
        tcBorders.append(edge_el)


def _center_images(para):
    """Center paragraphs containing inline images."""
    has_image = any(run._element.find(qn("w:drawing")) is not None for run in para.runs)
    if has_image:
        para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        para.paragraph_format.first_line_indent = Cm(0)


def _insert_toc_at_top(doc, config: TemplateConfig):
    """Insert TOC at document beginning."""
    p = doc.add_paragraph()
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    run = p.add_run("目录")
    run.bold = True
    run.font.size = Pt(config.heading.h1_size_pt)
    _set_east_asia(run, config.font.heading_chinese)
    toc_p = doc.add_paragraph()
    toc_p.paragraph_format.first_line_indent = Cm(0)
    insert_toc(toc_p, "目录")
    body = doc.element.body
    body.insert(0, toc_p._element)
    body.insert(0, p._element)


def _set_east_asia(run, font_name: str):
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    rfonts.set(qn("w:eastAsia"), font_name)
