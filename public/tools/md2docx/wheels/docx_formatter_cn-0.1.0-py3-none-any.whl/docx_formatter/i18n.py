"""Minimal i18n module for docx-formatter.

Usage:
    from docx_formatter.i18n import _
    print(_("template.course_paper"))

Set language via environment variable:
    export DOCX_FORMATTER_LANG=en
"""

import json
import os
from pathlib import Path

_DEFAULT_LANG = "zh"
_FALLBACK = {}


def _load_locale(lang: str) -> dict:
    locale_dir = Path(__file__).resolve().parent / "locales"
    file_path = locale_dir / f"{lang}.json"
    if not file_path.exists():
        return {}
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


def _get_text(key: str, lang: str = None) -> str:
    if lang is None:
        lang = os.environ.get("DOCX_FORMATTER_LANG", _DEFAULT_LANG)

    # Lazy load fallback
    global _FALLBACK
    if not _FALLBACK:
        _FALLBACK = _load_locale(_DEFAULT_LANG)

    translations = _load_locale(lang)
    return translations.get(key, _FALLBACK.get(key, key))


# Public API
def _(key: str) -> str:
    return _get_text(key)


def get_current_lang() -> str:
    return os.environ.get("DOCX_FORMATTER_LANG", _DEFAULT_LANG)


def set_lang(lang: str):
    os.environ["DOCX_FORMATTER_LANG"] = lang
